"""Release version number."""
__version__ = '3.0.8'  # noqa
