"""Handler reponse utilities."""

from .cors_headers import CORSHeaders  # noqa

cors = CORSHeaders
