import requests, json

def lambda_handler(event, context):
    webhook = 'http://http-el-github-listener-devops.apps.ocp-cf-pvt.labocp.net'
    httpResponse = requests.post(webhook)
    print (httpResponse)
